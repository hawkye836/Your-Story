document.addEventListener('DOMContentLoaded', () => {
  // Navbar scroll effect
  const nav = document.querySelector('.navbar');
  window.addEventListener('scroll', () => {
    nav.classList.toggle('scrolled', window.scrollY > 50);
  });

  // Parallax
  const hero = document.querySelector('.hero');
  window.addEventListener('scroll', () => {
    let sc = window.pageYOffset;
    hero.style.backgroundPositionY = `${sc * 0.5}px`;
  });

  // Scroll-reveal
  const srEls = document.querySelectorAll('.scroll-reveal');
  const reveal = () => {
    srEls.forEach(el => {
      const top = el.getBoundingClientRect().top;
      if (top < window.innerHeight - 100) el.classList.add('revealed');
    });
  };
  window.addEventListener('scroll', reveal);
  reveal();

  // Typewriter
  document.querySelectorAll('.typewriter').forEach(el => {
    const txt = el.textContent; el.textContent = '';
    let i = 0;
    const speed = 100;
    const type = () => {
      if (i < txt.length) {
        el.textContent += txt.charAt(i++);
        setTimeout(type, speed);
      }
    };
    type();
  });
});
